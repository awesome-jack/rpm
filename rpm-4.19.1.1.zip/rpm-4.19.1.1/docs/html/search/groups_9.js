var searchData=
[
  ['macro_20api_2e_0',['Macro API.',['../group__rpmmacro.html',1,'']]]
];
