var searchData=
[
  ['fcolor_5fe_0',['FCOLOR_e',['../group__rpmfc.html#gaa23b13b6981bcb4ab0b86235e23cd1c4',1,'rpmfc.h']]],
  ['fdopx_5fe_1',['fdOpX_e',['../group__rpmio.html#ga3f29a6d794c5c4d3283466f388021181',1,'rpmio.h']]]
];
