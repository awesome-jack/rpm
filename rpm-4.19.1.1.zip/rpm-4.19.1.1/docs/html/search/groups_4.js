var searchData=
[
  ['data_20types_3a_0',['Data types:',['../group__datatypes.html',1,'']]],
  ['database_20api_2e_1',['Database API.',['../group__rpmdb.html',1,'']]],
  ['dependency_20set_20api_2e_2',['Dependency Set API.',['../group__rpmds.html',1,'']]]
];
