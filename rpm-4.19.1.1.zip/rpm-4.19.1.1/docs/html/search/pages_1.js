var searchData=
[
  ['librpm_20api_20documentation_2e_0',['librpm API Documentation.',['../index.html',1,'']]]
];
