var indexSectionsWithContent =
{
  0: "(_abcdefhiklmnopqrstuvx",
  1: "apr",
  2: "ahr",
  3: "afhprsu",
  4: "_abcdefhiklmnopqrstuv",
  5: "fhpqru",
  6: "fhpru",
  7: "bcfilpqrstuvx",
  8: "hr",
  9: "(abcdfhilmopqrstuv",
  10: "dlt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

