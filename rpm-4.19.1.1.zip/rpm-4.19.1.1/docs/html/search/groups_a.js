var searchData=
[
  ['openpgp_20api_2e_0',['OpenPGP API.',['../group__rpmpgp.html',1,'']]]
];
