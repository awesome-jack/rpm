var searchData=
[
  ['bdev_0',['BDEV',['../group__rpmfiles.html#ggac552490ea6d3ba8db6fc29c800c22e3fae43bcaae76090fd5d491271fd6f8e8d2',1,'rpmfiles.h']]]
];
