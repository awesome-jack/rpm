var searchData=
[
  ['sock_0',['SOCK',['../group__rpmfiles.html#ggac552490ea6d3ba8db6fc29c800c22e3fa3f9b2e54721b240241ed87965d569f68',1,'rpmfiles.h']]]
];
