var searchData=
[
  ['valid_0',['valid',['../structpgpPktKeyV3__s.html#afff1851a4fc5e7f5039056d369dd0979',1,'pgpPktKeyV3_s']]],
  ['verify_20api_2e_1',['Verify API.',['../group__rpmvf.html',1,'']]],
  ['verify_5fcontexts_2',['VERIFY_CONTEXTS',['../group__rpmvf.html#gga88edb36096996aa24e1fc3385cb2140aa09c2f45ded7cbf565f15290a6a10b1ae',1,'rpmcli.h']]],
  ['verify_5fdeps_3',['VERIFY_DEPS',['../group__rpmvf.html#gga88edb36096996aa24e1fc3385cb2140aa10d4f3dc3e2647a7a676495169493235',1,'rpmcli.h']]],
  ['verify_5ffiles_4',['VERIFY_FILES',['../group__rpmvf.html#gga88edb36096996aa24e1fc3385cb2140aacb7b877f30fc12551ad7bcb8e20b801c',1,'rpmcli.h']]],
  ['verify_5fscript_5',['VERIFY_SCRIPT',['../group__rpmvf.html#gga88edb36096996aa24e1fc3385cb2140aa543b11a6e7cb720ff3b3741d89d0c2f1',1,'rpmcli.h']]],
  ['version_6',['version',['../structpgpPktPubkey__s.html#a2bb317231138c8dd5d58cde3f2d22a0a',1,'pgpPktPubkey_s::version'],['../structpgpPktSigV3__s.html#a12562561708e05e645d3e173c2cf2339',1,'pgpPktSigV3_s::version'],['../structpgpPktSigV4__s.html#a36c52e02ee235ac6a769ec64b79d7220',1,'pgpPktSigV4_s::version'],['../structpgpPktSymkey__s.html#ac349e9715dee13590c8bb75360b16704',1,'pgpPktSymkey_s::version'],['../structpgpPktOnepass__s.html#a7b147df58803e1cce74876a1b20086c1',1,'pgpPktOnepass_s::version'],['../structpgpPktKeyV3__s.html#a938936d2df98d45bb79147754c8a436b',1,'pgpPktKeyV3_s::version'],['../structpgpPktKeyV4__s.html#ae2474cfd7306fc9741f20a2535ab8cde',1,'pgpPktKeyV4_s::version']]]
];
