var searchData=
[
  ['querying_20package_20headers_3a_0',['Querying package headers:',['../group__headquery.html',1,'']]]
];
