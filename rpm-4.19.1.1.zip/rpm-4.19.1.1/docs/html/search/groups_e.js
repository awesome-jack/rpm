var searchData=
[
  ['signal_20queue_20api_2e_0',['Signal Queue API.',['../group__rpmsq.html',1,'']]],
  ['signature_20api_2e_1',['Signature API.',['../group__rpmsign.html',1,'']]],
  ['signature_20tags_20api_2e_2',['Signature Tags API.',['../group__signature.html',1,'']]],
  ['statistics_20api_2e_3',['Statistics API.',['../group__rpmsw.html',1,'']]],
  ['string_20manipulation_20api_2e_4',['String Manipulation API.',['../group__rpmstring.html',1,'']]],
  ['string_20pool_20api_2e_5',['String Pool API.',['../group__rpmstrpool.html',1,'']]]
];
