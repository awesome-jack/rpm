var searchData=
[
  ['fd_5ft_0',['FD_t',['../group__rpmtypes.html#ga078f4187c683508f3147e94397bab8d5',1,'rpmtypes.h']]],
  ['fdopx_1',['fdOpX',['../group__rpmio.html#ga53af71b7aaa8140dcc4e6e4b68c03d0a',1,'rpmio.h']]]
];
