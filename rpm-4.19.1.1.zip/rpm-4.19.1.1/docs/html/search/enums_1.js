var searchData=
[
  ['headergetflags_5fe_0',['headerGetFlags_e',['../group__header.html#gae10b109d8e56faba07f4743b797b893a',1,'header.h']]],
  ['hmagic_1',['hMagic',['../group__header.html#ga2572591faf5430cdf28aaf9f70d74fa4',1,'header.h']]]
];
