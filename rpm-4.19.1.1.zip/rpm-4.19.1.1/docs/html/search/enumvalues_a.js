var searchData=
[
  ['url_5fis_5fdash_0',['URL_IS_DASH',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56a65ce47b498e38dfe851d350107b86cb0',1,'rpmurl.h']]],
  ['url_5fis_5fftp_1',['URL_IS_FTP',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56a73c9c198188c069b467ce593d9413475',1,'rpmurl.h']]],
  ['url_5fis_5fhkp_2',['URL_IS_HKP',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56ae3410c399bbd830783bb877d1a55eaad',1,'rpmurl.h']]],
  ['url_5fis_5fhttp_3',['URL_IS_HTTP',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56a9cec1f8f01bd18cbe16cef81830fd95f',1,'rpmurl.h']]],
  ['url_5fis_5fhttps_4',['URL_IS_HTTPS',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56a54350c4a233015b91be84a91e51bbb49',1,'rpmurl.h']]],
  ['url_5fis_5fpath_5',['URL_IS_PATH',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56ab83b361a4814f376a40035d5b837d66f',1,'rpmurl.h']]],
  ['url_5fis_5funknown_6',['URL_IS_UNKNOWN',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56aadafeb790bb74bf766bea5fdde6e0e1c',1,'rpmurl.h']]]
];
