var searchData=
[
  ['logging_20api_2e_0',['Logging API.',['../group__rpmlog.html',1,'']]]
];
