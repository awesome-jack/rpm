var searchData=
[
  ['data_0',['data',['../structrpmtd__s.html#a173629ecdd3950c4685a3d34524dc412',1,'rpmtd_s']]],
  ['data_20types_3a_1',['Data types:',['../group__datatypes.html',1,'']]],
  ['database_20api_2e_2',['Database API.',['../group__rpmdb.html',1,'']]],
  ['dependency_20set_20api_2e_3',['Dependency Set API.',['../group__rpmds.html',1,'']]],
  ['deprecated_20list_4',['Deprecated List',['../deprecated.html',1,'']]]
];
