var searchData=
[
  ['xdir_0',['XDIR',['../group__rpmfiles.html#ggac552490ea6d3ba8db6fc29c800c22e3fa1d73dc463abcb5f0ec3167f3107aa2ea',1,'rpmfiles.h']]]
];
