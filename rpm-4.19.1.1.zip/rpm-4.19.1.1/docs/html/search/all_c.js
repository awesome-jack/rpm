var searchData=
[
  ['macro_20api_2e_0',['Macro API.',['../group__rpmmacro.html',1,'']]],
  ['macrofiles_1',['macrofiles',['../group__rpmrc.html#gae63ceb25d4146b91751ccf857f67f654',1,'rpmmacro.h']]]
];
