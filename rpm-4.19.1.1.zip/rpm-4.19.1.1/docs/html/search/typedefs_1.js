var searchData=
[
  ['header_0',['Header',['../group__rpmtypes.html#gacb1ffe4e2d96b8277f9f46ecc0c7b8a6',1,'rpmtypes.h']]]
];
