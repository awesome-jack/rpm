var searchData=
[
  ['url_20manipulation_20api_2e_0',['URL Manipulation API.',['../group__rpmurl.html',1,'']]]
];
