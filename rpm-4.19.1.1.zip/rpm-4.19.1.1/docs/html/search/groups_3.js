var searchData=
[
  ['callback_20signature_20_26_20types_2e_0',['Callback signature &amp; types.',['../group__rpmcallback.html',1,'']]],
  ['command_20line_20api_2e_1',['Command Line API.',['../group__rpmcli.html',1,'']]]
];
