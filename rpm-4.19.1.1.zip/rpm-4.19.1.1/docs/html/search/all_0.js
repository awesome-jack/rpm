var searchData=
[
  ['_28un_29installing_20packages_3a_0',['(un)Installing packages:',['../group__install.html',1,'']]]
];
