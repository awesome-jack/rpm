var searchData=
[
  ['showquerypackage_0',['showQueryPackage',['../group__rpmcli.html#ga9804d2470580108b1b82862356d9561d',1,'rpmcli.h']]],
  ['showverifypackage_1',['showVerifyPackage',['../group__rpmcli.html#ga7ae16c8552f03140867f5e8a4d1b97ae',1,'rpmcli.h']]],
  ['sig_2',['sig',['../unionpgpPktPre__u.html#a33fc894a20ae76d303f02ebb73b224bb',1,'pgpPktPre_u']]],
  ['signal_20queue_20api_2e_3',['Signal Queue API.',['../group__rpmsq.html',1,'']]],
  ['signature_20api_2e_4',['Signature API.',['../group__rpmsign.html',1,'']]],
  ['signature_20tags_20api_2e_5',['Signature Tags API.',['../group__signature.html',1,'']]],
  ['signflags_6',['signflags',['../structrpmSignArgs.html#a134d7404dd0ec8a8ae25bf7aa5a6ef2e',1,'rpmSignArgs']]],
  ['signhash16_7',['signhash16',['../structpgpPktSigV3__s.html#a941fceb4ef3a39f485e17e68cd4917fa',1,'pgpPktSigV3_s']]],
  ['signid_8',['signid',['../structpgpPktSigV3__s.html#a64e8dc971d519bbdcb7f455608e30b94',1,'pgpPktSigV3_s::signid'],['../structpgpPktOnepass__s.html#a68be25a3db27512f20623670d8335d43',1,'pgpPktOnepass_s::signid']]],
  ['sigtype_9',['sigtype',['../structpgpPktSigV3__s.html#aaa7b5317c774b2711833442b60e234ac',1,'pgpPktSigV3_s::sigtype'],['../structpgpPktSigV4__s.html#af2c88aee7ee5c919983303eea9f39ece',1,'pgpPktSigV4_s::sigtype'],['../structpgpPktOnepass__s.html#a0910d2454ddd5b6224413e02d671acdd',1,'pgpPktOnepass_s::sigtype']]],
  ['size_10',['size',['../structrpmtd__s.html#a2aef78a2387a05e9a556661307aa552a',1,'rpmtd_s']]],
  ['sock_11',['SOCK',['../group__rpmfiles.html#ggac552490ea6d3ba8db6fc29c800c22e3fa3f9b2e54721b240241ed87965d569f68',1,'rpmfiles.h']]],
  ['statistics_20api_2e_12',['Statistics API.',['../group__rpmsw.html',1,'']]],
  ['string_20manipulation_20api_2e_13',['String Manipulation API.',['../group__rpmstring.html',1,'']]],
  ['string_20pool_20api_2e_14',['String Pool API.',['../group__rpmstrpool.html',1,'']]],
  ['symkey_15',['symkey',['../unionpgpPktPre__u.html#a03633b11fa82e12909c0b1c29fa82d31',1,'pgpPktPre_u']]]
];
