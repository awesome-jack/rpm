var searchData=
[
  ['transaction_20element_20api_2e_0',['Transaction Element API.',['../group__rpmte.html',1,'']]],
  ['transaction_20set_20api_2e_1',['Transaction Set API.',['../group__rpmts.html',1,'']]]
];
