var searchData=
[
  ['showquerypackage_0',['showQueryPackage',['../group__rpmcli.html#ga9804d2470580108b1b82862356d9561d',1,'rpmcli.h']]],
  ['showverifypackage_1',['showVerifyPackage',['../group__rpmcli.html#ga7ae16c8552f03140867f5e8a4d1b97ae',1,'rpmcli.h']]]
];
