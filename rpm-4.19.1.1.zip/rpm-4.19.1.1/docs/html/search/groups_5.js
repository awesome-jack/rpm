var searchData=
[
  ['file_20and_20path_20manipulation_20api_2e_0',['File and Path Manipulation API.',['../group__rpmfileutil.html',1,'']]],
  ['file_20classification_20api_2e_1',['File Classification API.',['../group__rpmfc.html',1,'']]],
  ['file_20info_20set_20api_2e_2',['File Info Set API.',['../group__rpmfiles.html',1,'']]],
  ['file_20info_20set_20iterator_20api_2e_3',['File Info Set Iterator API.',['../group__rpmfi.html',1,'']]]
];
