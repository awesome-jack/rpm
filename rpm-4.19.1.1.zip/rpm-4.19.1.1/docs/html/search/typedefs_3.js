var searchData=
[
  ['qspecf_5ft_0',['QSpecF_t',['../group__rpmcli.html#gafa54a3a8ccb46ec2154b15d18d63c7bd',1,'rpmcli.h']]],
  ['qvf_5ft_1',['QVF_t',['../group__rpmcli.html#ga33a05b1483e2e6d8ca57d8928faef763',1,'rpmcli.h']]]
];
