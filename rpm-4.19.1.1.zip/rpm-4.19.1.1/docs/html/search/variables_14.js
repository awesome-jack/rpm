var searchData=
[
  ['valid_0',['valid',['../structpgpPktKeyV3__s.html#afff1851a4fc5e7f5039056d369dd0979',1,'pgpPktKeyV3_s']]],
  ['version_1',['version',['../structpgpPktPubkey__s.html#a2bb317231138c8dd5d58cde3f2d22a0a',1,'pgpPktPubkey_s::version'],['../structpgpPktSigV3__s.html#a12562561708e05e645d3e173c2cf2339',1,'pgpPktSigV3_s::version'],['../structpgpPktSigV4__s.html#a36c52e02ee235ac6a769ec64b79d7220',1,'pgpPktSigV4_s::version'],['../structpgpPktSymkey__s.html#ac349e9715dee13590c8bb75360b16704',1,'pgpPktSymkey_s::version'],['../structpgpPktOnepass__s.html#a7b147df58803e1cce74876a1b20086c1',1,'pgpPktOnepass_s::version'],['../structpgpPktKeyV3__s.html#a938936d2df98d45bb79147754c8a436b',1,'pgpPktKeyV3_s::version'],['../structpgpPktKeyV4__s.html#ae2474cfd7306fc9741f20a2535ab8cde',1,'pgpPktKeyV4_s::version']]]
];
