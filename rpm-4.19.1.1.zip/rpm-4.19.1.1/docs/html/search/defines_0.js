var searchData=
[
  ['header_5fimage_0',['HEADER_IMAGE',['../rpmtag_8h.html#a074e24cc0f3da5b73bdd53ff9ab28df4',1,'rpmtag.h']]]
];
