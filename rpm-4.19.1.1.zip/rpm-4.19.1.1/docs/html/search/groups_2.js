var searchData=
[
  ['build_20api_2e_0',['Build API.',['../group__rpmbuild.html',1,'']]],
  ['building_20_26_20signing_20packages_3a_1',['Building &amp; signing packages:',['../group__buildsign.html',1,'']]]
];
