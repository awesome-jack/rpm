var searchData=
[
  ['u_0',['u',['../structrpmsw__s.html#aafe43442180eb7051d02f2efd40df459',1,'rpmsw_s']]],
  ['ufdcopy_1',['ufdCopy',['../group__rpmio.html#ga1ee2645278d43d4d9e5a8761879ec674',1,'rpmio.h']]],
  ['uid_2',['uid',['../unionpgpPktPre__u.html#a216a938c035181e7feb66728291309a4',1,'pgpPktPre_u']]],
  ['uninstall_5fnone_3',['UNINSTALL_NONE',['../group__rpmcli.html#ga08b15fb71e839cc3694d1c806f5649b0',1,'rpmcli.h']]],
  ['url_20manipulation_20api_2e_4',['URL Manipulation API.',['../group__rpmurl.html',1,'']]],
  ['url_5fis_5fdash_5',['URL_IS_DASH',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56a65ce47b498e38dfe851d350107b86cb0',1,'rpmurl.h']]],
  ['url_5fis_5fftp_6',['URL_IS_FTP',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56a73c9c198188c069b467ce593d9413475',1,'rpmurl.h']]],
  ['url_5fis_5fhkp_7',['URL_IS_HKP',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56ae3410c399bbd830783bb877d1a55eaad',1,'rpmurl.h']]],
  ['url_5fis_5fhttp_8',['URL_IS_HTTP',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56a9cec1f8f01bd18cbe16cef81830fd95f',1,'rpmurl.h']]],
  ['url_5fis_5fhttps_9',['URL_IS_HTTPS',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56a54350c4a233015b91be84a91e51bbb49',1,'rpmurl.h']]],
  ['url_5fis_5fpath_10',['URL_IS_PATH',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56ab83b361a4814f376a40035d5b837d66f',1,'rpmurl.h']]],
  ['url_5fis_5funknown_11',['URL_IS_UNKNOWN',['../group__rpmurl.html#gga3c0dd3c42784390f1b3102ededcf5f56aadafeb790bb74bf766bea5fdde6e0e1c',1,'rpmurl.h']]],
  ['urlgetfile_12',['urlGetFile',['../group__rpmurl.html#gadb6ec7dec93aed32774209a954cef0fe',1,'rpmurl.h']]],
  ['urlisurl_13',['urlIsURL',['../group__rpmurl.html#ga22b100d54b531488e82c40551e60a065',1,'rpmurl.h']]],
  ['urlpath_14',['urlPath',['../group__rpmurl.html#gaa53d11202529a428d1211701c7693c7b',1,'rpmurl.h']]],
  ['urltype_15',['urltype',['../group__rpmurl.html#ga76bbf4efecb9e8f7382ae791e22a75b2',1,'rpmurl.h']]],
  ['urltype_5fe_16',['urltype_e',['../group__rpmurl.html#ga3c0dd3c42784390f1b3102ededcf5f56',1,'rpmurl.h']]],
  ['usecs_17',['usecs',['../structrpmop__s.html#a441e7e2e6184a6e052c3955065326214',1,'rpmop_s']]]
];
