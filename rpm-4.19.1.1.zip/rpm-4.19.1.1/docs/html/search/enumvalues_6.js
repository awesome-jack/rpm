var searchData=
[
  ['query_5ffor_5fdumpfiles_0',['QUERY_FOR_DUMPFILES',['../group__rpmcli.html#ggaa71f3bd5c169daa2d2f2d64ab7caae02a2c02e7d72723563ce7a208efcfd70da8',1,'rpmcli.h']]],
  ['query_5ffor_5flist_1',['QUERY_FOR_LIST',['../group__rpmcli.html#ggaa71f3bd5c169daa2d2f2d64ab7caae02a92be2d9da5d78fe59198e551b5a9d402',1,'rpmcli.h']]],
  ['query_5ffor_5fstate_2',['QUERY_FOR_STATE',['../group__rpmcli.html#ggaa71f3bd5c169daa2d2f2d64ab7caae02a400a01b07a31992017a526db8165bf10',1,'rpmcli.h']]]
];
