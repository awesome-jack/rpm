var searchData=
[
  ['oldpath_0',['oldPath',['../structrpmRelocation__s.html#a945f7f53153cf221e5692d74df8f5efb',1,'rpmRelocation_s']]],
  ['onepass_1',['onepass',['../unionpgpPktPre__u.html#a3d0a8be191fd647dfb68dfeb55d23ce3',1,'pgpPktPre_u']]],
  ['openpgp_20api_2e_2',['OpenPGP API.',['../group__rpmpgp.html',1,'']]]
];
