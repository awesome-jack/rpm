var searchData=
[
  ['argument_20manipulation_20api_2e_0',['Argument Manipulation API.',['../group__rpmargv.html',1,'']]]
];
