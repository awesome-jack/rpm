---
date: 14 Apr 2016
section: 8
title: 'RPM-SYSLOG'
---

NAME
====

rpm-plugin-syslog - Syslog plugin for the RPM Package Manager

Description
===========

The plugin writes basic information about rpm transactions to the syslog
- like transactions run and packages installed or removed.

Configuration
=============

There are currently no options for this plugin in particular. See
**rpm-plugins**(8) on how to control plugins in general.

SEE ALSO
========

**rpm**(8), **rpm-plugins**(8)
